export type Entry={id:string,title:string,sport:string,entry:string,hostProtocol:1,saveSchema:number,runtimeVersion:string,sha256:string,bytes:number};
export function loadGameArtifact(id:string,url:string,signal?:AbortSignal):Promise<{html:string,entry:Entry,root:string,entryRoot:string}>;
export function frameDocument(html:string,boot:Record<string,unknown>):string;
